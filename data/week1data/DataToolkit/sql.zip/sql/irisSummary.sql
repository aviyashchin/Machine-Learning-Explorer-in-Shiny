-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nyc
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `irisSummary`
--

DROP TABLE IF EXISTS `irisSummary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irisSummary` (
  `SepalLengthMin` float DEFAULT NULL,
  `SepalLengthMax` float DEFAULT NULL,
  `SepalLengthMean` float DEFAULT NULL,
  `SepalWidthMin` float DEFAULT NULL,
  `SepalWidthMax` float DEFAULT NULL,
  `SepalWidthMean` float DEFAULT NULL,
  `PetalLengthMin` float DEFAULT NULL,
  `PetalLengthMax` float DEFAULT NULL,
  `PetalLengthMean` float DEFAULT NULL,
  `PetalWidthMin` float DEFAULT NULL,
  `PetalWidthMax` float DEFAULT NULL,
  `PetalWidthMean` float DEFAULT NULL,
  `Species` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `irisSummary`
--

LOCK TABLES `irisSummary` WRITE;
/*!40000 ALTER TABLE `irisSummary` DISABLE KEYS */;
INSERT INTO `irisSummary` VALUES (4.3,5.8,5.006,2.3,4.4,3.428,1,1.9,1.462,0.1,0.6,0.246,'setosa'),(4.9,7,5.936,2,3.4,2.77,3,5.1,4.26,1,1.8,1.326,'versicolor'),(4.9,7.9,6.588,2.2,3.8,2.974,4.5,6.9,5.552,1.4,2.5,2.026,'virginica');
/*!40000 ALTER TABLE `irisSummary` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-03-23 13:57:27
