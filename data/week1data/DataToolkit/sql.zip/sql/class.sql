DROP DATABASE my_db;
CREATE DATABASE my_db;
SHOW DATABASES;
USE my_db

CREATE TABLE bootcamp
       (course_name varchar(255),
       course_instructor varchar(255)
);

SHOW TABLES;

# Data Manipulation

INSERT INTO bootcamp VALUES ('R','Paul');
INSERT INTO bootcamp (course_instructor, course_name) VALUES ('Vivian','Hadoop');
INSERT INTO bootcamp VALUES ('Python', 'Vivian'), ('others', 'unknown');

SELECT course_name FROM bootcamp;
SELECT * FROM bootcamp;
SELECT course_name AS name FROM bootcamp;
SELECT * FROM bootcamp LIMIT 2;
SELECT * FROM bootcamp WHERE course_instructor <> 'vivian';
SELECT * FROM bootcamp WHERE course_name = 'R';
SELECT * FROM bootcamp WHERE course_instructor = 'Paul' AND course_name = 'R';
SELECT * FROM bootcamp WHERE course_instructor <> 'vivian' OR course_name = 'Hadoop';
SELECT * FROM bootcamp ORDER BY course_instructor, course_name;
SELECT * FROM bootcamp ORDER BY course_instructor DESC, course_name DESC;
SELECT course_instructor, COUNT(1) AS count from bootcamp group by course_instructor;
SELECT course_instructor FROM bootcamp GROUP BY course_instructor HAVING COUNT(1)>1;
UPDATE bootcamp SET course_instructor = 'Bryan' WHERE course_name = 'Python';
SELECT course_instructor FROM bootcamp WHERE course_name = 'Python';
 
CREATE TABLE iris
     (
         SepalLength float,
         SepalWidth float,
         PetalLength float,
         PetalWidth float,
         Species varchar(255)
    );

LOAD DATA LOCAL INFILE '/home/demo/iris.csv' 
     INTO TABLE iris
     FIELDS TERMINATED BY ','
     OPTIONALLY ENCLOSED BY '"'
     LINES TERMINATED BY '\n'
     IGNORE 1 lines; 


# Exercise 1
SELECT COUNT(DISTINCT Species) FROM iris;
SELECT Species, COUNT(1) AS count FROM iris GROUP BY Species;

CREATE TABLE irisSummary
     (
           SepalLengthMin FLOAT,
           SepalLengthMax FLOAT,
           SepalLengthMean FLOAT,
           SepalWidthMin FLOAT,
           SepalWidthMax FLOAT,
           SepalWidthMean FLOAT,
           PetalLengthMin FLOAT,
           PetalLengthMax FLOAT,
           PetalLengthMean FLOAT,
           PetalWidthMin FLOAT,
           PetalWidthMax FLOAT,
           PetalWidthMean FLOAT,
           Species VARCHAR(255)
     );

INSERT INTO irisSummary
         SELECT MIN(SepalLength), 
                MAX(SepalLength), 
                AVG(SepalLength),
                MIN(SepalWidth), 
                MAX(SepalWidth), 
                AVG(SepalWidth),
                MIN(PetalLength), 
                MAX(PetalLength), 
                AVG(PetalLength),
                MIN(PetalWidth), 
                MAX(PetalWidth), 
                AVG(PetalWidth),
                Species
         FROM iris
         GROUP BY Species;

DELETE FROM irisSummary WHERE Species = 'virginica';
TRUNCATE TABLE irisSummary;
SELECT * FROM irisSummary;
DROP TABLE irisSummary;

# Exercise 2
CREATE TABLE air2008
(
    Year INT,
    Month INT,
    DayofMonth INT,
    DayOfWeek INT,
    DepTime INT,
    CRSDepTime INT,
    ArrTime INT,
    CRSArrTime INT,
    UniqueCarrier VARCHAR(255),
    FlightNum INT,
    TailNum VARCHAR(255),
    ActualElapsedTime INT,
    CRSElapsedTime INT,
    AirTime INT,
    ArrDelay VARCHAR(255),
    DepDelay INT,
    Origin VARCHAR(255),
    Dest VARCHAR(255),
    Distance INT,
    TaxiIn INT,
    TaxiOut INT,
    Cancelled INT,
    CancellationCode VARCHAR(255),
    Diverted INT,
    CarrierDelay INT,
    WeatherDelay INT,
    NASDelay INT,
    SecurityDelay INT,
    LateAircraftDelay INT
);

LOAD DATA LOCAL INFILE '2008_short.csv' 
INTO TABLE air2008
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
IGNORE 1 lines;
SELECT COUNT(1) FROM air2008;
SELECT COUNT(1) FROM air2008 WHERE DepDelay <= 0;
SELECT UniqueCarrier, Month, AVG(DepDelay) as delay_carrier_month 
    FROM air2008 
    WHERE DepDelay > 0
    GROUP BY UniqueCarrier, Month
    ORDER BY delay_carrier_month DESC;


# Join
CREATE TABLE author
     (
         surname VARCHAR(255),
         nationality VARCHAR(255),
         deceased VARCHAR(255)
     );

INSERT INTO author
     VALUES ("Tukey", "US", "yes"),
            ("Venables", "Australia", "no"),
            ("Tierney", "US", "no"),
	    ("Ripley", "UK", "no");

CREATE TABLE book
     (
         name VARCHAR(255),
         title VARCHAR(255)
     );

INSERT INTO book
     VALUES  ("Tukey", "Exploratory Data Analysis"),
             ("Tierney", "LISP-STAT"),
             ("Ripley", "Stochastic Simulation"), 
             ("McNeil", "Interactive Data Analysis"),
             ("R Core", "An Introduction to R");

SELECT * FROM author INNER JOIN book ON author.surname = book.name;
SELECT * FROM author LEFT OUTER JOIN book ON author.surname = book.name;
SELECT * FROM author RIGHT OUTER JOIN book ON author.surname = book.name;

SELECT * FROM author
     LEFT OUTER JOIN book 
     ON author.surname = book.name
     UNION
     SELECT * FROM author
     RIGHT OUTER JOIN book 
     ON author.surname = book.name;
